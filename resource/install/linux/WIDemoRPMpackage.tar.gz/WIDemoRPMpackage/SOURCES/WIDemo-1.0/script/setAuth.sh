#! /bin/sh

INSTALL_PATH=$1

if [ -z $INSTALL_PATH ];then
    echo "auth params can't be null"
    exit 1
fi


LOG_PATH=/var/FusionAccess/WIDemo

if [ ! -d ${LOG_PATH} ];then
mkdir -p ${LOG_PATH}
fi

echo "setAuth InPath" $INSTALL_PATH
#该目录所在用户组
result=0
chown -R gandalf:FusionAccess $INSTALL_PATH
temp=$?
result=$((result+temp))

chown -R gandalf:FusionAccess $LOG_PATH
temp=$?
result=$((result+temp))

#普通文件
#设置文件权限
find $INSTALL_PATH -type f -exec chmod 600 {} \;
temp=$?
result=$((result+temp))

#设置目录权限
find $INSTALL_PATH -type d -exec chmod 700 {} \;
temp=$?
result=$((result+temp))

find $LOG_PATH -type f -exec chmod 600 {} \;
temp=$?
result=$((result+temp))

find $LOG_PATH -type d -exec chmod 700 {} \;
temp=$?
result=$((result+temp))

#WIDemo脚本
chmod 510 $INSTALL_PATH/script/*.sh
temp=$?
result=$((result+temp))

chmod 510 $INSTALL_PATH/script/WIDemoService
temp=$?
result=$((result+temp))


#tomcat文件
chmod -R 500 $INSTALL_PATH/tomcat/bin
temp=$?
result=$((result+temp))

#jre文件
chmod -R 700 $INSTALL_PATH/jre/bin
temp=$?
result=$((result+temp))
exit $result
