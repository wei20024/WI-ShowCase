#! /bin/sh

EXE_PATH=$PWD

CUR_PATH=`dirname $0`
cd $CUR_PATH
pwd_prefix=$(echo "$PWD" | grep -oP "[\\s\\S]*(?=script)" | tr -d '\r')
if [ ! -z $pwd_prefix ];then
    cd $pwd_prefix
fi


CATALINA_HOME=$PWD/tomcat
pid=$(ps -ww -eo pid,cmd | grep ${CATALINA_HOME} |grep java |grep -v grep |awk '{print $1}')
myarray=($pid)
length=${#myarray[@]}

if [ $length -gt 0 ];then
   echo "WIDemo Service is already starting..."
else
    export JRE_HOME=$PWD/jre
    sh $CATALINA_HOME/bin/startup.sh > /dev/null 2>&1
    echo "WIDemo Service is starting now..." 
fi
cd $EXE_PATH
