#! /bin/sh

EXE_PATH=$PWD

CUR_PATH=`dirname $0`
cd $CUR_PATH
pwd_prefix=$(echo "$PWD" | grep -oP "[\\s\\S]*(?=script)" | tr -d '\r')
if [ ! -z $pwd_prefix ];then
    cd $pwd_prefix
fi

CATALINA_HOME=$PWD/tomcat
pid=$(ps -ww -eo pid,cmd | grep ${CATALINA_HOME} |grep java |grep -v grep |awk '{print $1}')
st=0
myarray=($pid)
for i in ${myarray[@]};do
    if [ ! -z $i ];then
       st=1
       export JRE_HOME=$PWD/jre
       logmsg="try to shutdown WIService ";
       time=$(date +"%Y-%m-%d %H:%M:%S");
       user=$(whoami);
       logmsg="$time   $user  $logmsg"
       echo $logmsg
       sh ${CATALINA_HOME}/bin/shutdown.sh > /dev/null 2>&1 #关闭tomcat 
    fi
done

if [ "$st" != "0" ];then
    sleep 5
fi

sh ./script/closepid.sh
echo "success to shutdown tomcat." 
cd $EXE_PATH
