#! /bin/sh
# Copyright  1998-2009, Huawei Technologies Co., Ltd.  ALL Rights Reserved.

# ### BEGIN INIT INFO
# Provides:          
# Required-Start:    
# Should-Start:      
# Required-Stop:     
# Should-Stop:       
# Default-Start:     
# Default-Stop:
# Short-Description: 
# Description:       
### END INIT INFO

if [ -n "$1" ]
then
   INSTALL_PATH=$1
else
   INSTALL_PATH="/opt/WIDemo"
fi
echo INSTALLpath ${INSTALL_PATH}
if [ ! -f ${INSTALL_PATH}/script/WIDemoService ] ; then
	echo "WIDemoService service not found"
	exit 1
fi


echo "Ready to install... "

echo "step1:set WI as linux service"
#####WI SERVICE files copy#####
SERVICE_FILE=${INSTALL_PATH}/script/WIDemoService
sed -i '/^INSTALL_PATH/c\INSTALL_PATH='${INSTALL_PATH}'' $SERVICE_FILE
chmod +x $SERVICE_FILE
rm -f /etc/init.d/WIDemoService
cp -f  $SERVICE_FILE /etc/init.d/WIDemoService

cd ${INSTALL_PATH}
if [ -f tomcat.tar.gz ];then 
tar -xzf tomcat.tar.gz
rm tomcat.tar.gz
fi
if [ -f jre.tar.gz ];then
tar -xzf jre.tar.gz
rm jre.tar.gz
fi
chmod +x jre/bin/*

##### format configure file #####
echo "step11:format config file to unix"
cron_file="${INSTALL_PATH}/tomcat/WI/ROOT/WEB-INF/classes/controller.properties"
dos2unix $cron_file > /dev/null 2>&1

#####tomcat secure#####
chmod 510 $INSTALL_PATH/script/*.sh
$PWD/script/setAuth.sh $INSTALL_PATH

#####iptables set#####
iptables -A INPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
iptables -A INPUT -p tcp --dport 9003 -j ACCEPT
iptables -A INPUT -p tcp --dport 9080 -j ACCEPT
iptables -A INPUT -p tcp --dport 9443 -j ACCEPT
iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-ports 9080
iptables -t nat -A PREROUTING -p tcp --dport 443 -j REDIRECT --to-ports 9443
iptables-save > /etc/iptables.save
iptables-restore /etc/iptables.save

cp $INSTALL_PATH/script/setenv.sh $INSTALL_PATH/tomcat/bin
#startup script
ln -sf $INSTALL_PATH/script/startup.sh $INSTALL_PATH/startup.sh

chmod 510 $INSTALL_PATH/startup.sh
#shutdown script
ln -sf $INSTALL_PATH/script/shutdown.sh $INSTALL_PATH/shutdown.sh 
chmod 510 $INSTALL_PATH/shutdown.sh

echo "success to install WIDemo"
exit 0
