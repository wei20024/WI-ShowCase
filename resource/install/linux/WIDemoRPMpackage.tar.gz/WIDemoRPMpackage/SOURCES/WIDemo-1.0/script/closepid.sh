#! /bin/sh

EXE_PATH=$PWD

CUR_PATH=`dirname $0`
cd $CUR_PATH
pwd_prefix=$(echo "$PWD" | grep -oP "[\\s\\S]*(?=script)" | tr -d '\r')
if [ ! -z $pwd_prefix ];then
    cd $pwd_prefix
fi

CATALINA_HOME=$PWD/tomcat
pid=$(ps -ww -eo pid,cmd | grep ${CATALINA_HOME} |grep java |grep -v grep |awk '{print $1}')
st=0
myarray=($pid)
for i in ${myarray[@]};do
    if [ ! -z $i ];then
        writeLog "kill -9 $i"
        #等待时间结束后，偿试强制结束tomcat进程 
        kill -9 $i
    fi
done

cd $EXE_PATH
