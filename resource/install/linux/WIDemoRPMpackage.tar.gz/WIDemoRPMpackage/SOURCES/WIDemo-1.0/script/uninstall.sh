#!/bin/bash
### BEGIN INIT INFO
# Provides:          WI
# Required-Start:    $network $remote_fs
# Required-Stop:     $network $remote_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start daemon at boot time
# Description:       Enable service provided by daemon.
### END INIT INFO

if [ -n "$1" ]
then
   INSTALL_PATH=$1
else
   INSTALL_PATH="/opt/WIDemo"
fi



echo "Ready to uninstall... "

echo "step1:stop WIDemoService"
output=`service WIDemoService status`
echo "----step1.1 WIService status is "$output
output=`service WIDemoService stop`
echo "----step1.2 WIDemoService stop result is "$output

rm -f /etc/init.d/WIDemoService

if [ -d $INSTALL_PATH ];then
    rm -rf $INSTALL_PATH
fi


######del iptables regular#####
echo "step4:remove correspond linux iptables"
#iptables -D INPUT -p tcp --dport 80 -j ACCEPT
#iptables -D INPUT -p tcp --dport 443 -j ACCEPT
#iptables -D INPUT -p tcp --dport 9003 -j ACCEPT
#iptables -D INPUT -p tcp --sport 8548 -j ACCEPT
#iptables -D INPUT -p tcp --sport 6773 -j ACCEPT
#iptables -D INPUT -p tcp --sport 6772 -j ACCEPT
#iptables -D INPUT -p tcp --dport 9080 -j ACCEPT
#iptables -D INPUT -p tcp --dport 9443 -j ACCEPT
#iptables -t nat -D PREROUTING -p tcp --dport 80 -j REDIRECT --to-ports 9080
#iptables -t nat -D PREROUTING -p tcp --dport 443 -j REDIRECT --to-ports 9443

iptables-save > /etc/iptables.save

echo "success to uninstall WIDemo"
exit 0
