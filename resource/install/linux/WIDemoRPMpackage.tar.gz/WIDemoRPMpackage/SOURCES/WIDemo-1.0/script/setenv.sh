#!/bin/sh

WIDemo_LOGHOME=/var/FusionAccess/WIDemo
TOMCAT_LOG_HOME=$WIDemo_LOGHOME/tomcat
CATALINA_OUT=$TOMCAT_LOG_HOME/catalina.out 
if [ ! -d "$TOMCAT_LOG_HOME" ];then
   mkdir -p $TOMCAT_LOG_HOME
fi

JAVA_OPTS="-Xms1024m -Xmx1024m -Xss256k -XX:PermSize=64m -XX:MaxPermSize=64M -XX:NewRatio=4 -XX:+UseConcMarkSweepGC -XX:MaxTenuringThreshold=7 -XX:+PrintGCTimeStamps -Dorg.apache.catalina.connector.RECYCLE_FACADES=false -Djava.net.preferIPv4Stack=true -Djava.net.preferIPv6Addresses=false $JAVA_OPTS -DWIDemo.LOGHOME=$WIDemo_LOGHOME -Dtomcat.log.home=$TOMCAT_LOG_HOME" 
