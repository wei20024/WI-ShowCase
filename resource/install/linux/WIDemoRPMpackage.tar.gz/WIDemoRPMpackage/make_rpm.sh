#!/bin/sh

name=WIDemo
version=1.0
cd SOURCES/${name}-${version}
if [ -d jre ]; then 
echo "tar jre"
tar -czf jre.tar.gz jre/
rm -rf jre/
fi
if [ -d tomcat ]; then
echo "tar tomcat"
tar -czf tomcat.tar.gz tomcat/
rm -rf tomcat/
fi
#change to SOURCE/
cd ..
tar -czvf ${name}-${version}.tar.gz ${name}-${version}
#change to INSTALLROOT
cd ..
rpmbuild -bb  SPECS/demo.spec 
